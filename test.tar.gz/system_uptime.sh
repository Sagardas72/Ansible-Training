#!/bin/bash

/usr/bin/uptime > /home/test/uptime.log
